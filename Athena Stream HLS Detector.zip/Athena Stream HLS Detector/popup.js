document.addEventListener('DOMContentLoaded', function () {
  let clearButton = document.getElementById('clear');
  clearButton.addEventListener('click', function () {
    chrome.runtime.sendMessage({ clearAll: true });
    chrome.storage.local.get(['tabs', 'regexPresets'], function (data) {
      let regexPresets = data.regexPresets || [];
      let tabs = data.tabs || {};

      // Clear the tabs object
      for (let tabId in tabs) {
        if (tabs.hasOwnProperty(tabId)) {
          delete tabs[tabId];
        }
      }

      chrome.storage.local.set({ tabs: tabs, regexPresets: regexPresets }, function () {
        let error = chrome.runtime.lastError;
        if (error) {
          console.error(error);
        } else {
          window.location.reload();
        }
      });
    });
  });

  let searchBox = document.getElementById('searchBox');
  let downloadButton = document.getElementById('downloadButton');
  let settingsButton = document.getElementById('settingsButton');
  settingsButton.addEventListener('click', function () {
    chrome.tabs.create({ 'url': chrome.runtime.getURL('settings.html') });
  });
function displayUrls(keyword) {
  chrome.storage.local.get(['tabs', 'regexPresets', 'sentTitles'], function (data) {
    let content = document.getElementById('content');
    content.innerHTML = ''; // Clear previous results

    let titleToUrlsMap = new Map();
    let sentTitles = data.sentTitles || [];

    Object.values(data.tabs).forEach(function (tab) {
      tab.forEach(function (video) {
        let displayUrls = [];
        let regexPresets = data.regexPresets || [];
        let title = video.title;

        regexPresets.forEach(function (item) {
          if (item.regex) {
            let regex = new RegExp(item.regex, 'gi');
            title = title.replace(regex, '');
          }
        });

        video.urls.forEach(function (url) {
          if (!url.includes('player.html') && title.toLowerCase() !== 'asd video player') {
            if (url.toLowerCase().includes(keyword.toLowerCase()) || title.toLowerCase().includes(keyword.toLowerCase())) {
              let filename = '';
              let truncatedUrl = false;

              // Extract filename from the URL if available
              const lastSlashIndex = url.lastIndexOf('/');
              if (lastSlashIndex !== -1 && lastSlashIndex < url.length - 1) {
                const filenameWithQuery = url.substring(lastSlashIndex + 1);
                const queryIndex = filenameWithQuery.indexOf('?');
                if (queryIndex !== -1) {
                  filename = filenameWithQuery.substring(0, queryIndex);
                } else {
                  filename = filenameWithQuery;
                }
              } else {
                // Use truncated URL for URLs without a specific filename
                filename = url.substring(0, 50) + '...'; // Display only the first 50 characters
                truncatedUrl = true;
              }

              displayUrls.push({ filename: filename, url: url, timestamp: video.timestamp, truncated: truncatedUrl });
            }
          }
        });

        if (displayUrls.length > 0) {
          titleToUrlsMap.set(title, displayUrls);
        }
      });
    });

    let videoInfos = [];

    let promises = []; // Array to hold all promises

    chrome.storage.sync.get(['allowDuplicateUrls'], async function (result) {
      let allowDuplicateUrls = result.allowDuplicateUrls;
      let sentTitles = [];

      for (let [title, urls] of titleToUrlsMap.entries()) {
        if (allowDuplicateUrls || !sentTitles.includes(title)) {
          sentTitles.push(title);
          let lastSevenUrls = urls.slice(-7); // Get the last 7 URLs

          // Extract the year from the title
          let match = title.match(/(\d{4})$/);
          let year = match ? match[0] : null;
          let titleWithoutYear = year ? title.slice(0, -4).trim() : title;

          // Fetch data from TMDB API
          let response = await fetch(`https://api.themoviedb.org/3/search/movie?api_key=baf66526108dea78b59e123801d8acf9&query=${encodeURIComponent(titleWithoutYear)}${year ? '&year=' + year : ''}`);
          let data = await response.json();
          if (data && data.results && data.results.length > 0) {
            let matchingTitle = data.results[0].title;
            let matchingYear = data.results[0].release_date ? data.results[0].release_date.slice(0, 4) : null;
            title = `${matchingTitle}${matchingYear ? ' (' + matchingYear + ')' : ''}`;
          }

          videoInfos.push({
            Title: [title.trim()],
            URLs: lastSevenUrls.map(urlObj => urlObj.url),
          });
        }

        let videoContainer = document.createElement('div');
        videoContainer.style.display = 'flex';
        videoContainer.style.flexDirection = 'column';
        videoContainer.style.justifyContent = 'space-between';
        videoContainer.style.alignItems = 'flex-start';

        let videoTitle = document.createElement('h1');
        videoTitle.textContent = title;
        videoTitle.style.color = 'black';

        let deleteButton = document.createElement('button');
        deleteButton.textContent = 'X';
        deleteButton.style.marginLeft = '5px'; // Adds padding to the button
        deleteButton.style.marginBottom = '4px';
        deleteButton.style.textAlign = 'center'; // Aligns the text ('X') to the center of the button
        deleteButton.style.verticalAlign = 'middle'; // Vertically aligns the button in its container
        deleteButton.style.fontSize = '6px'; // adjust as needed
        deleteButton.addEventListener('click', function () {
          chrome.storage.local.get(['tabs'], function (data) {
            let tabs = data.tabs;
            for (let tabId in tabs) {
              tabs[tabId] = tabs[tabId].filter(function (item) {
                return item.title !== title;
              });
            }
            chrome.storage.local.set({ 'tabs': tabs }, function () {
              if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
              } else {
                content.removeChild(videoContainer);
              }
            });
          });
        });
        videoTitle.appendChild(deleteButton);

        videoContainer.appendChild(videoTitle);

        urls.forEach(function (urlObj) {
          let urlElement = document.createElement('a');
          if (urlObj.truncated) {
            urlElement.textContent = '...' + urlObj.url.slice(-50); // Display truncated URL from the end
          } else {
            urlElement.textContent = urlObj.filename;
          }
          urlElement.href = urlObj.url;
          urlElement.target = '_blank';
          urlElement.addEventListener('click', function (e) {
            if (e.button === 0) {
              // left click
              e.preventDefault();
              const playerUrl = chrome.runtime.getURL('player.html') + `?url=${encodeURIComponent(urlObj.url)}&title=${encodeURIComponent(title)}`;
              chrome.windows.create({ url: playerUrl, type: 'popup', width: 800, height: 600 });
            }
            // for other types of click, including right click, do nothing and let the browser handle it
          });
          videoContainer.appendChild(urlElement);

          let timestampElement = document.createElement('span');
          let timestampText = '';
          if (urlObj.timestamp) {
            let timestamp = new Date(urlObj.timestamp);
            if (!isNaN(timestamp)) {
              timestampText = ' - ' + timestamp.toLocaleString();
            }
          }
          timestampElement.textContent = timestampText;
          videoContainer.appendChild(timestampElement);
        });

        content.appendChild(videoContainer);
      }

      // Save sent titles to local storage
      chrome.storage.local.set({ sentTitles: sentTitles });

      // Send videoInfos to the server
      videoInfos.forEach((videoInfo) => {
        chrome.storage.local.get(['tabs'], function (data) {
          Object.values(data.tabs).forEach(function (tab) {
            tab.forEach(function (video) {
              if (videoInfo.Title.includes(video.title)) {
                videoInfo.Title = [video.title];
              }
            });
          });

          let videoInfoJson = JSON.stringify(videoInfo);

          fetch('http://localhost:8765/', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: videoInfoJson,
          })
            .then((response) => response.text())
            .then(console.log)
            .catch(console.error);
        });
      });
    });
  });
}

  // Load the last keyword from storage and set it as searchBox's value
  chrome.storage.local.get(['keyword'], function (data) {
    if (data.keyword) {
      searchBox.value = data.keyword;
      displayUrls(data.keyword); // Display URLs for the keyword
    } else {
      displayUrls(''); // Display all URLs if no keyword was stored
    }
  });

  // When the value of searchBox changes, display URLs for the keyword and store the keyword
  searchBox.addEventListener('input', function () {
    let keyword = searchBox.value;
    console.log('Search keyword: ', keyword);
    displayUrls(keyword);

    // Store the keyword
    chrome.storage.local.set({ 'keyword': keyword });
  });


  
  function promptEpisodeSelection(seriesTitle, episodeMetadata) {
    let episodeList = episodeMetadata.map((episode) => ({
      label: `S${episode.seasonNumber}E${episode.episodeNumber} - ${episode.episodeName}`,
      value: episode,
    }));
  
    let optionsText = episodeList.map((episode, index) => `${index + 1}. ${episode.label}`).join('\n');
    let selectedIndex = window.prompt(`Please select the correct episode for "${seriesTitle}":\n${optionsText}`);
  
    if (selectedIndex !== null) {
      let selectedEpisode = episodeList[parseInt(selectedIndex) - 1];
      return selectedEpisode ? selectedEpisode.value : null;
    }
  
    return null;
  }
  
 
  downloadButton.addEventListener('click', function () {
    chrome.storage.local.get(['tabs', 'regexPresets'], function (data) {
      let keyword = searchBox.value.toLowerCase(); // Get the keyword from the search box

      let urlsSet = new Set(); // Use a Set to store unique URLs

      Object.values(data.tabs).forEach(function (tab) {
        tab.forEach(function (video, index) {
          let title = video.title.trim(); // Trim leading/trailing spaces from the title
          let regexPresets = data.regexPresets || [];
          regexPresets.forEach(function (item) {
            if (item.regex) {
              let regex = new RegExp(item.regex);
              title = title.replace(regex, '');
            }
          });

          video.urls.forEach(function (url) {
            let lowercaseUrl = url.toLowerCase();
            if (lowercaseUrl.includes(keyword) || title.toLowerCase().includes(keyword)) {
              let entry = title + '\n' + url.trim(); // Separate title and URL, trim leading/trailing spaces
              urlsSet.add(entry); // Add the entry to the Set to ensure uniqueness
            }
          });
        });
      });

      // Create the content string for the file
      let content = Array.from(urlsSet).join('\n');

      let blob = new Blob([content], { type: 'text/plain' });
      let url = URL.createObjectURL(blob);

      let downloadLink = document.createElement('a');
      downloadLink.href = url;
      downloadLink.download = 'urls.txt';
      downloadLink.style.display = 'none';
      document.body.appendChild(downloadLink);

      downloadLink.click();

      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    });
  });

    // Added event listener for the Open Player button
  document.getElementById('openPlayerButton').addEventListener('click', function () {
    const playerUrl = chrome.runtime.getURL('player.html');
    chrome.windows.create({ url: playerUrl, type: 'popup', width: 800, height: 600 });
  });
});