document.addEventListener('DOMContentLoaded', function () {
  let clearButton = document.getElementById('clear');
  clearButton.addEventListener('click', function () {
    chrome.runtime.sendMessage({ clearAll: true });
    chrome.storage.local.get(['tabs', 'regexPresets'], function (data) {
      let regexPresets = data.regexPresets || [];
      let tabs = data.tabs || {};

      // Clear the tabs object
      for (let tabId in tabs) {
        if (tabs.hasOwnProperty(tabId)) {
          delete tabs[tabId];
        }
      }

      chrome.storage.local.set({ tabs: tabs, regexPresets: regexPresets }, function () {
        let error = chrome.runtime.lastError;
        if (error) {
          console.error(error);
        } else {
          window.location.reload();
        }
      });
    });
  });

  let searchBox = document.getElementById('searchBox');
  let downloadButton = document.getElementById('downloadButton');
  let settingsButton = document.getElementById('settingsButton');
  settingsButton.addEventListener('click', function () {
    chrome.tabs.create({ 'url': chrome.runtime.getURL('settings.html') });
  });

  function displayUrls(keyword) {
    chrome.storage.local.get(['tabs', 'regexPresets'], function (data) {
      let content = document.getElementById('content');
      content.innerHTML = ''; // Clear previous results

      let titleToUrlsMap = new Map();

      Object.values(data.tabs).forEach(function (tab) {
        tab.forEach(function (video) {
          let displayUrls = [];
          let regexPresets = data.regexPresets || [];
          let title = video.title;

          regexPresets.forEach(function (item) {
            if (item.regex) {
              let regex = new RegExp(item.regex, 'gi');
              title = title.replace(regex, '');
            }
          });

          video.urls.forEach(function (url) {
            // Exclude URLs of video player and titles of 'Video Player'
            if (!url.includes('player.html') && title.toLowerCase() !== 'asd video player') {
              if (url.toLowerCase().includes(keyword.toLowerCase()) || title.toLowerCase().includes(keyword.toLowerCase())) {
                let filename = '';
                let truncatedUrl = false;

                // Extract filename from the URL if available
                const lastSlashIndex = url.lastIndexOf('/');
                if (lastSlashIndex !== -1 && lastSlashIndex < url.length - 1) {
                  const filenameWithQuery = url.substring(lastSlashIndex + 1);
                  const queryIndex = filenameWithQuery.indexOf('?');
                  if (queryIndex !== -1) {
                    filename = filenameWithQuery.substring(0, queryIndex);
                  } else {
                    filename = filenameWithQuery;
                  }
                } else {
                  // Use truncated URL for URLs without a specific filename
                  filename = url.substring(0, 50) + '...'; // Display only the first 50 characters
                  truncatedUrl = true;
                }

                displayUrls.push({ filename: filename, url: url, timestamp: video.timestamp, truncated: truncatedUrl });
              }
            }
          });

          if (displayUrls.length > 0) {
            titleToUrlsMap.set(title, displayUrls);
          }
        });
      });

      for (let [title, urls] of titleToUrlsMap.entries()) {
        let videoContainer = document.createElement('div');
        videoContainer.style.display = 'flex';
        videoContainer.style.flexDirection = 'column';
        videoContainer.style.justifyContent = 'space-between';
        videoContainer.style.alignItems = 'flex-start';

        let videoTitle = document.createElement('h1');
        videoTitle.textContent = title;
        videoTitle.style.color = 'black';

        let deleteButton = document.createElement('button');
        deleteButton.textContent = 'X';
        deleteButton.style.marginLeft = '5px'; // Adds padding to the button
        deleteButton.style.marginBottom = '4px';
        deleteButton.style.textAlign = 'center'; // Aligns the text ('X') to the center of the button
        deleteButton.style.verticalAlign = 'middle'; // Vertically aligns the button in its container
        deleteButton.style.fontSize = '6px'; // adjust as needed
        deleteButton.addEventListener('click', function () {
          chrome.storage.local.get(['tabs'], function (data) {
            let tabs = data.tabs;
            for (let tabId in tabs) {
              tabs[tabId] = tabs[tabId].filter(function (item) {
                return item.title !== title;
              });
            }
            chrome.storage.local.set({ 'tabs': tabs }, function () {
              if (chrome.runtime.lastError) {
                console.error(chrome.runtime.lastError);
              } else {
                content.removeChild(videoContainer);
              }
            });
          });
        });
        videoTitle.appendChild(deleteButton);

        videoContainer.appendChild(videoTitle);

        urls.forEach(function (urlObj) {
          let urlElement = document.createElement('a');
          if (urlObj.truncated) {
            urlElement.textContent = '...' + urlObj.url.slice(-50); // Display truncated URL from the end
          } else {
            urlElement.textContent = urlObj.filename;
          }
          urlElement.href = urlObj.url;
          urlElement.target = '_blank';
          urlElement.addEventListener('click', function (e) {
            if (e.button === 0) {
              // left click
              e.preventDefault();
              const playerUrl = chrome.runtime.getURL('player.html') + `?url=${encodeURIComponent(urlObj.url)}&title=${encodeURIComponent(title)}`;
              chrome.windows.create({ url: playerUrl, type: 'popup', width: 800, height: 600 });
            }
            // for other types of click, including right click, do nothing and let the browser handle it
          });
          videoContainer.appendChild(urlElement);

          let timestampElement = document.createElement('span');
          let timestampText = '';
          if (urlObj.timestamp) {
            let timestamp = new Date(urlObj.timestamp);
            if (!isNaN(timestamp)) {
              timestampText = ' - ' + timestamp.toLocaleString();
            }
          }
          timestampElement.textContent = timestampText;
          videoContainer.appendChild(timestampElement);
        });

        content.appendChild(videoContainer);
      }
    });
  }

  displayUrls('');

  searchBox.addEventListener('input', function () {
    let keyword = searchBox.value;
    console.log('Search keyword: ', keyword);
    displayUrls(keyword);
  });

  downloadButton.addEventListener('click', function () {
    chrome.storage.local.get(['tabs', 'regexPresets'], function (data) {
      let keyword = searchBox.value.toLowerCase(); // Get the keyword from the search box

      let urlsSet = new Set(); // Use a Set to store unique URLs

      Object.values(data.tabs).forEach(function (tab) {
        tab.forEach(function (video, index) {
          let title = video.title.trim(); // Trim leading/trailing spaces from the title
          let regexPresets = data.regexPresets || [];
          regexPresets.forEach(function (item) {
            if (item.regex) {
              let regex = new RegExp(item.regex);
              title = title.replace(regex, '');
            }
          });

          video.urls.forEach(function (url) {
            let lowercaseUrl = url.toLowerCase();
            if (lowercaseUrl.includes(keyword) || title.toLowerCase().includes(keyword)) {
              let entry = title + '\n' + url.trim(); // Separate title and URL, trim leading/trailing spaces
              urlsSet.add(entry); // Add the entry to the Set to ensure uniqueness
            }
          });
        });
      });

      // Create the content string for the file
      let content = Array.from(urlsSet).join('\n');

      let blob = new Blob([content], { type: 'text/plain' });
      let url = URL.createObjectURL(blob);

      let downloadLink = document.createElement('a');
      downloadLink.href = url;
      downloadLink.download = 'urls.txt';
      downloadLink.style.display = 'none';
      document.body.appendChild(downloadLink);

      downloadLink.click();

      document.body.removeChild(downloadLink);
      URL.revokeObjectURL(url);
    });
  });

  document.getElementById('send-to-ASD').addEventListener('click', function () {
    let keyword = searchBox.value.toLowerCase(); // Get the keyword from the search box

    chrome.storage.local.get(['tabs', 'regexPresets', 'allowDuplicateUrls', 'sentTitles'], function (data) {
      let titleToUrlsMap = new Map();
      let sentTitles = data.sentTitles || [];

      Object.values(data.tabs).forEach(function (tab) {
        tab.forEach(function (video) {
          let title = video.title.trim(); // Trim leading/trailing spaces from the title
          let regexPresets = data.regexPresets || [];
          regexPresets.forEach(function (item) {
            if (item.regex) {
              let regex = new RegExp(item.regex);
              title = title.replace(regex, '');
            }
          });

          let filteredUrls = video.urls.filter(url => {
            let lowercaseUrl = url.toLowerCase();
            return lowercaseUrl.includes(keyword) || title.toLowerCase().includes(keyword);
          });

          if (!titleToUrlsMap.has(title)) {
            titleToUrlsMap.set(title, filteredUrls);
          } else {
            let existingUrls = titleToUrlsMap.get(title);
            titleToUrlsMap.set(title, existingUrls.concat(filteredUrls));
          }
        });
      });

      let videoInfos = [];
      let allowDuplicateUrls = data.allowDuplicateUrls || false;

      for (let [title, urls] of titleToUrlsMap.entries()) {
        if (allowDuplicateUrls || !sentTitles.includes(title)) {
          sentTitles.push(title);

          let lastSevenUrls = urls.slice(-7); // Get the last 7 URLs
          videoInfos.push({
            Title: [title],
            URLs: lastSevenUrls,
          });
        }
      }

      chrome.storage.local.set({ sentTitles: sentTitles });

      videoInfos.forEach((videoInfo) => {
        let videoInfoJson = JSON.stringify(videoInfo);

        fetch('http://localhost:8765/', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: videoInfoJson,
        })
          .then((response) => response.text())
          .then(console.log)
          .catch(console.error);
      });
    });
  });

  // Added event listener for the Open Player button
  document.getElementById('openPlayerButton').addEventListener('click', function () {
    const playerUrl = chrome.runtime.getURL('player.html');
    chrome.windows.create({ url: playerUrl, type: 'popup', width: 800, height: 600 });
  });
});