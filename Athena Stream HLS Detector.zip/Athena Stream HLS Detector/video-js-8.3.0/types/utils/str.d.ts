export function toLowerCase(string: string): string;
export function toTitleCase(string: string): string;
export function titleCaseEquals(str1: string, str2: string): boolean;
//# sourceMappingURL=str.d.ts.map