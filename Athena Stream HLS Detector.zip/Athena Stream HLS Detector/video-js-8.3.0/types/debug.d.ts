export default videojs;
import videojs from "./video";
//# sourceMappingURL=debug.d.ts.map