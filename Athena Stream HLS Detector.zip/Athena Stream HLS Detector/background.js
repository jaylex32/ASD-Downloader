let tabs = {};

chrome.webRequest.onBeforeRequest.addListener(
  function(details) {
    chrome.storage.local.get(['enableVtt', 'enableMp4', 'enableDash', 'banlist'], function(data) {
      let enableVtt = data.enableVtt;
      let enableMp4 = data.enableMp4;
      let enableDash = data.enableDash;
      let banlist = data.banlist || [];

      let url = new URL(details.url);
      if ((url.pathname.endsWith('m3u8')) ||
          (url.pathname.endsWith('vtt') && enableVtt) ||
          (url.pathname.endsWith('mp4') && enableMp4) ||
          (url.pathname.endsWith('dash') && enableDash)) {
        chrome.tabs.get(details.tabId, function(tab) {
          if (!tabs[details.tabId]) {
            tabs[details.tabId] = [];
          }
          
          let title = tab.title;
          banlist.forEach(word => {
            let regex = new RegExp(word, 'gi');
            title = title.replace(regex, '');
          });

          let lastVideo = tabs[details.tabId][tabs[details.tabId].length - 1];
          
          if (!lastVideo || (lastVideo.urls.length === 6 || lastVideo.urls.length === 2 && !url.pathname.endsWith('vtt')) || lastVideo.urls.includes(details.url)) {
            tabs[details.tabId].push({title: title, urls: [details.url]});
            if (tabs[details.tabId].length > 12) {
              tabs[details.tabId].shift();
            }
          } else {
            lastVideo.urls.push(details.url);
          }

          chrome.storage.local.set({tabs: tabs});

          let totalURLs = Object.values(tabs).reduce((total, tab) => total + tab.length, 0);
          chrome.browserAction.setBadgeBackgroundColor({ color: "#F00" });
          chrome.browserAction.setBadgeText({ text: String(totalURLs) });
        });
      }
    });
  },
  {urls: ["<all_urls>"]}
);

// Message Listener
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
  if (request.clearAll) {
    clearAllURLs();
  }
});

// Clear All URLs function
const clearAllURLs = () => {
  tabs = {}; // Clear all tabs and their URLs
  chrome.storage.local.set({tabs: tabs}, function() {
    if (chrome.runtime.lastError) {
      console.error('Failed to clear URLs:', chrome.runtime.lastError);
    } else {
      console.log('URLs cleared successfully.');
    }
  });

  chrome.browserAction.setBadgeBackgroundColor({ color: "#F00" });
  chrome.browserAction.setBadgeText({ text: String(0) }); // Set badge text to 0 as all URLs are cleared

  chrome.runtime.sendMessage({ urlStorage: true });
};