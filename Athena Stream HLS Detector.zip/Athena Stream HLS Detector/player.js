document.addEventListener('DOMContentLoaded', () => {
    // Set the desired width and height for the window
  const desiredWidth = 800; // Replace with your desired width in pixels
  const desiredHeight = 700; // Replace with your desired height in pixels

  // Resize the window
  window.resizeTo(desiredWidth, desiredHeight);
  
  const urlParams = new URLSearchParams(window.location.search);
  const videoUrlParam = urlParams.get('url');
  const videoTitleParam = decodeURIComponent(urlParams.get('title'));

  const player = videojs('videoPlayer', {
    techOrder: ['html5'],
    html5: {
      hls: {
        enableLowInitialPlaylist: true,
        smoothQualityChange: true,
        overrideNative: true
      }
    }
  });

  // Load the video source
  player.src({
    src: videoUrlParam,
    type: 'application/x-mpegURL' // Change this if your URL is a different type
  });

  // Play the video
  player.play();

  const playlistInput = document.getElementById('playlist-input');
  const addPlaylistButton = document.getElementById('add-playlist-button');
  const addToPlaylistButton = document.getElementById('add-to-playlist-button');
  const playlistElement = document.getElementById('playlist');
  const playlistItemsElement = document.getElementById('playlist-items');
  let playlists = JSON.parse(localStorage.getItem('playlists')) || [];

  // Create a new playlist
  addPlaylistButton.addEventListener('click', () => {
    const playlistName = playlistInput.value.trim();
    if (playlistName === '') {
      return;
    }

    const newPlaylist = {
      name: playlistName,
      videos: []
    };

    playlists.push(newPlaylist);
    playlistInput.value = '';
    renderPlaylists();
    savePlaylists();
  });

  // Add the current video to the selected playlist
  addToPlaylistButton.addEventListener('click', () => {
    const selectedPlaylistIndex = playlistElement.selectedIndex;
    if (selectedPlaylistIndex === -1) {
      return;
    }

    const selectedPlaylist = playlists[selectedPlaylistIndex];
    const video = {
      title: videoTitleParam,
      url: videoUrlParam
    };

    selectedPlaylist.videos.push(video);
    savePlaylists();
    renderPlaylistItems(selectedPlaylist);
  });

  // Render the playlists in the dropdown
  function renderPlaylists() {
    playlistElement.innerHTML = '';
    playlists.forEach((playlist) => {
      const option = document.createElement('option');
      option.text = playlist.name;
      playlistElement.add(option);
    });
  }

  // Render the playlist items for the selected playlist
function renderPlaylistItems(playlist) {
  const playlistItemsElement = document.getElementById('playlist-items');
  playlistItemsElement.innerHTML = '';

  playlist.videos.forEach((video, index) => {
    const listItem = document.createElement('li');

    const titleLink = document.createElement('a');
    titleLink.textContent = video.title;
    titleLink.href = '#';
    titleLink.addEventListener('click', () => {
      playVideo(video.url, video.title);
    });

    const removeButton = document.createElement('button');
    removeButton.textContent = 'x';
    removeButton.classList.add('remove-button');
    removeButton.style.lineHeight = '6px'; /* Adjust the line height to match the video title */
	removeButton.style.padding = '4px 6px'; /* Adjust the padding as needed */
    removeButton.style.fontSize = '12px'; /* Adjust the font size as needed */
    removeButton.addEventListener('click', () => {
      playlist.videos.splice(index, 1);
      savePlaylists();
      renderPlaylistItems(playlist);
    });

    const separator = document.createElement('hr');
    separator.classList.add('playlist-divider');

    listItem.appendChild(titleLink);
    listItem.appendChild(removeButton);
    listItem.appendChild(separator);
    playlistItemsElement.appendChild(listItem);
  });
}

function playVideo(url, title) {
  const player = videojs('videoPlayer');
  player.src({
    src: url,
    type: 'application/x-mpegURL'
  });
  player.play();

  // Remove any existing video title elements
  const existingTitleElements = document.querySelectorAll('#header h2');
  existingTitleElements.forEach(element => {
    element.remove();
  });

  // Create a new video title element
  const videoTitleElement = document.createElement('h2');
  videoTitleElement.textContent = title;
  videoTitleElement.style.fontSize = '12px';
  videoTitleElement.style.textAlign = 'center';
  videoTitleElement.style.marginTop = '10px';

  // Insert the video title element below the header
  const headerElement = document.getElementById('header');
  headerElement.appendChild(videoTitleElement);
}


  // Save the playlists to local storage
  function savePlaylists() {
    localStorage.setItem('playlists', JSON.stringify(playlists));
  }

// Initialize the player with the current playlist (if available)
function initializePlayer() {
  const selectedPlaylistIndex = playlistElement.selectedIndex;
  if (selectedPlaylistIndex === -1) {
    return;
  }

  const selectedPlaylist = playlists[selectedPlaylistIndex];
  renderPlaylistItems(selectedPlaylist);
  
  // Add an event listener to the playlist dropdown
  playlistElement.addEventListener('change', function() {
    const selectedPlaylistIndex = playlistElement.selectedIndex;
    if (selectedPlaylistIndex === -1) {
      return;
    }

    const selectedPlaylist = playlists[selectedPlaylistIndex];
    renderPlaylistItems(selectedPlaylist);
  });
}


  renderPlaylists();
  initializePlayer();

  // Get the video title element
  const videoTitleElement = document.createElement('h2');
  videoTitleElement.textContent = videoTitleParam;
  videoTitleElement.style.fontSize = '12px';
  videoTitleElement.style.textAlign = 'center';
  videoTitleElement.style.marginTop = '10px';

  // Insert the video title element below the header
  const headerElement = document.getElementById('header');
  headerElement.appendChild(videoTitleElement);

  document.getElementById('exportButton').addEventListener('click', exportPlaylist);

  function exportPlaylist() {
  const selectedPlaylistIndex = playlistElement.selectedIndex;
  if (selectedPlaylistIndex === -1) {
    return;
  }

  const selectedPlaylist = playlists[selectedPlaylistIndex];
  const playlistName = selectedPlaylist.name;

  // Generate the content for the .m3u8 file
  let playlistContent = "#EXTM3U\n";
  selectedPlaylist.videos.forEach((video) => {
    playlistContent += `#EXTINF:-1,${video.title}\n${video.url}\n`;
  });

  // Create a Blob object with the playlist content
  const blob = new Blob([playlistContent], { type: 'application/vnd.apple.mpegurl' });

  // Create a temporary anchor element to trigger the download
  const downloadLink = document.createElement('a');
  downloadLink.href = URL.createObjectURL(blob);
  downloadLink.download = `${playlistName}.m3u8`;
  downloadLink.click();
  URL.revokeObjectURL(downloadLink.href);
}

const deletePlaylistButton = document.getElementById('delete-playlist-button');
deletePlaylistButton.addEventListener('click', deletePlaylist);

function deletePlaylist() {
  const selectedPlaylistIndex = playlistElement.selectedIndex;
  if (selectedPlaylistIndex === -1) {
    return;
  }

  playlists.splice(selectedPlaylistIndex, 1);
  savePlaylists();
  renderPlaylists();
  initializePlayer();
}


});