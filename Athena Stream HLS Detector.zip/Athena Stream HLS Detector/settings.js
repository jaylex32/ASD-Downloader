document.getElementById('settings-form').addEventListener('submit', function(event) {
  event.preventDefault(); // Prevent the form from being submitted normally

  let regexPresets = [];
  
  for (let i = 1; i <= 10; i++) {
    let regexInput = document.getElementById('regex' + i);
    let presetInput = document.getElementById('preset' + i);
    if (regexInput && presetInput) {
      regexPresets.push({regex: regexInput.value, preset: presetInput.value});
    }
  }

  // Get checkbox values
  let enableVtt = document.getElementById('enableVtt').checked;
  let enableMp4 = document.getElementById('enableMp4').checked;
  let enableDash = document.getElementById('enableDash').checked;

  chrome.storage.local.set({
    regexPresets: regexPresets,
    enableVtt: enableVtt,
    enableMp4: enableMp4,
    enableDash: enableDash
  }, function() {
    console.log('Settings saved.');
  });
});

window.onload = function() {
  chrome.storage.local.get(['regexPresets', 'enableVtt', 'enableMp4', 'enableDash'], function(data) {
    if (data.regexPresets) {
      for (let i = 0; i < data.regexPresets.length; i++) {
        document.getElementById('regex' + (i+1)).value = data.regexPresets[i].regex;
        document.getElementById('preset' + (i+1)).value = data.regexPresets[i].preset;
      }
    }
    // Set checkbox values
    document.getElementById('enableVtt').checked = data.enableVtt || false;
    document.getElementById('enableMp4').checked = data.enableMp4 || false;
    document.getElementById('enableDash').checked = data.enableDash || false;
  });
}

document.addEventListener("DOMContentLoaded", function() {
  let allowDuplicateUrlsCheckbox = document.getElementById('allowDuplicateUrls');

  // Set the checkbox to match the saved state when the page loads
  chrome.storage.local.get(['allowDuplicateUrls'], function(data) {
    if (chrome.runtime.lastError) {
      console.error('Failed to load settings:', chrome.runtime.lastError);
    } else {
      allowDuplicateUrlsCheckbox.checked = data.allowDuplicateUrls || false;
      console.log('Loaded setting for allowDuplicateUrls:', data.allowDuplicateUrls);
    }
  });

  // Update the saved state in local storage when the checkbox is clicked
  allowDuplicateUrlsCheckbox.addEventListener('change', function() {
    chrome.storage.local.set({ allowDuplicateUrls: allowDuplicateUrlsCheckbox.checked }, function() {
      if (chrome.runtime.lastError) {
        console.error('Failed to save settings:', chrome.runtime.lastError);
      } else {
        console.log('Saved setting for allowDuplicateUrls:', allowDuplicateUrlsCheckbox.checked);
      }
    });
  });
});