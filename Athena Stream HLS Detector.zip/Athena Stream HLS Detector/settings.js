window.onload = function() {
  chrome.storage.local.get(['regexPresets', 'enableVtt', 'enableMp4', 'enableDash', 'banlist'], function(data) {
    if (data.regexPresets) {
      for (let i = 0; i < data.regexPresets.length; i++) {
        document.getElementById('regex' + (i+1)).value = data.regexPresets[i].regex;
        document.getElementById('preset' + (i+1)).value = data.regexPresets[i].preset;
      }
    }
    // Set checkbox values
    document.getElementById('enableVtt').checked = data.enableVtt || false;
    document.getElementById('enableMp4').checked = data.enableMp4 || false;
    document.getElementById('enableDash').checked = data.enableDash || false;

    // Load banlist
    let banlistInput = document.getElementById('banlist');
    if (data.banlist) {
      banlistInput.value = data.banlist.join(',\n');
    }
  });

  document.getElementById('settings-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from being submitted normally

    let regexPresets = [];
    for (let i = 1; i <= 10; i++) {
      let regexInput = document.getElementById('regex' + i);
      let presetInput = document.getElementById('preset' + i);
      if (regexInput && presetInput) {
        regexPresets.push({regex: regexInput.value, preset: presetInput.value});
      }
    }

    // Get checkbox values
    let enableVtt = document.getElementById('enableVtt').checked;
    let enableMp4 = document.getElementById('enableMp4').checked;
    let enableDash = document.getElementById('enableDash').checked;

    let banlistInput = document.getElementById('banlist');
    let banlistString = banlistInput.value;
    let banlist = banlistString.split(',').map(word => word.trim());

    chrome.storage.local.set({
      regexPresets: regexPresets,
      enableVtt: enableVtt,
      enableMp4: enableMp4,
      enableDash: enableDash,
      banlist: banlist
    }, function() {
      console.log('Settings saved.');
    });
  });

  let allowDuplicateUrlsCheckbox = document.getElementById('allowDuplicateUrls');
  chrome.storage.local.get(['allowDuplicateUrls'], function(data) {
    if (chrome.runtime.lastError) {
      console.error('Failed to load settings:', chrome.runtime.lastError);
    } else {
      allowDuplicateUrlsCheckbox.checked = data.allowDuplicateUrls || false;
      console.log('Loaded setting for allowDuplicateUrls:', data.allowDuplicateUrls);
    }
  });

  allowDuplicateUrlsCheckbox.addEventListener('change', function() {
    chrome.storage.local.set({ allowDuplicateUrls: allowDuplicateUrlsCheckbox.checked }, function() {
      if (chrome.runtime.lastError) {
        console.error('Failed to save settings:', chrome.runtime.lastError);
      } else {
        console.log('Saved setting for allowDuplicateUrls:', allowDuplicateUrlsCheckbox.checked);
      }
    });
  });
};